package com.aplicacion.QuickOrder.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.aplicacion.QuickOrder.model.Pedido;
import com.aplicacion.QuickOrder.repository.PedidoRepository;

@Service
public class PedidoService {
@Autowired    
    PedidoRepository pedidoRepository = new PedidoRepository();

    public List<Pedido> getPedidos(){
        return pedidoRepository.obtenerPedidos();
    }

    public Pedido getPedidosId(int id){
        return pedidoRepository.buscarPedidoId(id);
    }

    public Pedido savePedido(Pedido pedido){
        return pedidoRepository.agregarPedido(pedido);
    }

    public Pedido updatePedido(Pedido pedido){
        return pedidoRepository.actualizarPedido(pedido);
    }

    public String deletePedido(Pedido pedido){
        return pedidoRepository.eliminarPedido(pedido);
    }
}
