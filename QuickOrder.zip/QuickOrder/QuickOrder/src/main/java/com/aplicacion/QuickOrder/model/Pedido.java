package com.aplicacion.QuickOrder.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor

public class Pedido {
    private int idCliente;
    private String nombreCliente;
    private String rutCliente;

    private int idPedido;
    private String estadoPedido;
    private double montoTotalPedido;
    private String fechaPedido;
    private String tipoCategoriaPedido;
}
