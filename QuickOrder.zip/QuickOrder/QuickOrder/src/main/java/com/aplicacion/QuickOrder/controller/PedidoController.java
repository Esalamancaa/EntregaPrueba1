package com.aplicacion.QuickOrder.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.aplicacion.QuickOrder.model.Pedido;
import com.aplicacion.QuickOrder.service.PedidoService;

@RequestMapping
@RestController
public class PedidoController {
@Autowired

    private PedidoService pedidoService; 

    @GetMapping("api/v1/Pedidos")
    public List<Pedido> getPedido(Pedido pedido){
        return pedidoService.getPedidos();
    }

    @GetMapping("{id}")
    public Pedido getPedidoId(@PathVariable int id){
        return pedidoService.getPedidosId(id);
    }

    @PostMapping("api/v1/Pedidos/agregar")
    public Pedido agregarPedido(@RequestBody Pedido pedido){
        return pedidoService.savePedido(pedido);
    }

    @PutMapping("api/v1/Pedidos/actualizar")
    public Pedido updatePedido(@RequestBody Pedido pedido){
        return pedidoService.updatePedido(pedido);
    }

    @DeleteMapping("api/v1/Pedidos/borrar")
    public String deletePedido(@RequestBody Pedido pedido){
        return pedidoService.deletePedido(pedido);
    }
    
    
}
