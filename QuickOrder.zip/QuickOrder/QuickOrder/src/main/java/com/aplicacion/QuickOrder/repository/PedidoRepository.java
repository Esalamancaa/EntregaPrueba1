package com.aplicacion.QuickOrder.repository;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.aplicacion.QuickOrder.model.Pedido;

@Repository
public class PedidoRepository {

    public List<Pedido> listaPedidos = new ArrayList<>();

    public List<Pedido> obtenerPedidos(){
        return listaPedidos;
    }

    public Pedido buscarPedidoId(int id){
        for(Pedido pedido: listaPedidos){
            if(pedido.getIdPedido()==id){
                return pedido;
            }
            
        }
        return null;
    }

    public Pedido agregarPedido(Pedido pedido){

        Pedido pedido1 = new Pedido();
            pedido1.setIdCliente(pedido.getIdCliente());
            pedido1.setNombreCliente(pedido.getNombreCliente());
            pedido1.setRutCliente(pedido.getRutCliente());
            pedido1.setIdPedido(pedido.getIdPedido());
            pedido1.setEstadoPedido(pedido.getEstadoPedido());
            pedido1.setMontoTotalPedido(pedido.getMontoTotalPedido());
            pedido1.setTipoCategoriaPedido(pedido.getTipoCategoriaPedido());

        listaPedidos.add(pedido);

        return pedido;
    }

    public Pedido actualizarPedido(Pedido pedido){  
        for (int i = 0; i < listaPedidos.size();i++) {
            int idPosicion=i;

            Pedido pedido1 = new Pedido();
            pedido1.setIdCliente(pedido.getIdCliente());
            pedido1.setNombreCliente(pedido.getNombreCliente());
            pedido1.setRutCliente(pedido.getRutCliente());
            pedido1.setIdPedido(pedido.getIdPedido());
            pedido1.setEstadoPedido(pedido.getEstadoPedido());
            pedido1.setMontoTotalPedido(pedido.getMontoTotalPedido());
            pedido1.setTipoCategoriaPedido(pedido.getTipoCategoriaPedido());

            listaPedidos.add(idPosicion, pedido1);
            return pedido;
        }
        return null;
    }

    public String eliminarPedido(Pedido pedido){
        if(pedido != null){
            listaPedidos.remove(pedido);
            return "Pedido eliminado";
        }
        return null;
    }
}
